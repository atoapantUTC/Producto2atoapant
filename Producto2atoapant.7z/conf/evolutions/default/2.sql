# --- Sample dataset

# --- !Ups

insert into platose (id,name,categoria,costo,introduced,discontinued) values (  1,'arroz','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  2,'ceviche','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  3,'camarones','especialdsf','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  4,'langostinos ajillo','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  5,'ensaladas cesar','especiadsfl','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  6,'brownly','especdfsdfsdial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  7,'cafe','especdsfial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  8,'red foot','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  9,'atun','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  10,'salsa soya','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  11,'pimientos ajo','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  12,'arroz verde','especialdsf','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  13,'arrozasd','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  14,'arrozsad','especiadsfl','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  15,'arrozdsf','especdfsdfsdial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  16,'arrozfsd','especdsfial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  17,'arrozdsf','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  18,'arrozdsf','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  19,'arrozdsf','especial','24','2016-11-12','2016-09-09');
insert into platose (id,name,categoria,costo,introduced,discontinued) values (  20,'arrozdsf','especial','24','2016-11-12','2016-09-09');
# --- !Downs

delete from platose;

